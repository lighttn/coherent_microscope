clc; clear;addpath './fn' 

%% simulate the forward imaging process of Fourier ptychography
% simulate the high resolution complex object

% object amplitude 
objectAmplitude = double(imread('../../../Test_imgs/GXLK8161.tif')); % object amplitude image
objectAmplitude = imresize(objectAmplitude, [512, 512]); % resize the orig. img

% object phase 
objPhase = double(imread('../../../Test_imgs/CBFD3921.tif')); % object phase image 
objPhase = pi*imresize(objPhase, [512, 512])./max(max(objPhase)); % normalize to pi and resize 

% complex amplitude 
object = objectAmplitude.*exp(1i.*objPhase); % make it complex amplitude 

f101=figure(101);imshow(abs(object),[]); title('Input complex object abs (amplitude)');
saveas(f101, 'f101.jpg')
f102=figure(102);imshow(angle(object),[]); title('Input complex object ang (phase)');
saveas(f102, 'f102.jpg')

%% the LED illuminations
arraysize = 3; % size of LED array, even number 
num_LEDs = arraysize^2; % total number of LEDs ~ 225 

xlocation = zeros(1, num_LEDs); % LED's number in x 
ylocation = zeros(1, num_LEDs); % LED's number in y 

LED_period = 4; % 4 mm between adjacent LEDs
LED_distance = 90; % 90 mm between the LED matrix and the sample

% LED positions (mm) - square 
for i = 1:arraysize % from top left to bottom right 
    xlocation(1+arraysize*(i-1):arraysize+arraysize*(i-1)) = (-(arraysize-1)/2:1:(arraysize-1)/2)*LED_period;
    ylocation(1+arraysize*(i-1):arraysize+arraysize*(i-1)) = ((arraysize-1)/2-(i-1))*LED_period;
end

% LED positions (mm) - ring

% LED's x, y positions in theta (angle to surface normal) 
kx_relative = -sin(atan(xlocation/LED_distance)); % wavevector in x-axis = (sin(theta))
ky_relative = -sin(atan(ylocation/LED_distance));

%% parameters for optical setup 
lambda0 = 0.63e-6; % red laser 
k0 = 2*pi/lambda0; % wave number (frequency)
size_ccdpx = 2.75e-6; % sampling pixel size of the CCD 
mag = 4; % magnification 
size_reconpx = size_ccdpx / mag; % final pixel size of the reconstruction 
NA = 0.08; % NA of objective lens 

%% generate the low-pass filtered images

% m : ml = px_ccd : px_recon
[m, n] = size(object); % px nr of the high resolution object img (256)
ml = m/mag; 
nl = n/mag; % px nr of the lpf output img (64)

% image set 
imSeqLowRes_abs = zeros(ml, nl, arraysize^2); % output low-res image sequence 

size_x = size_reconpx*m;
size_y = size_reconpx*n;

% wavenumber (from the objective to LEDs)
kx = k0*kx_relative;
ky = k0*ky_relative;

% freq of full recon image
dkx = 2*pi/size_x;
dky = 2*pi/size_y;

% cut-off in Frequency domain 
cutoffFrequency = NA*k0; % objective-NA 

kmax = pi/size_ccdpx; 
[kxm, kym] = meshgrid(-kmax:2*kmax/(ml-1):kmax, -kmax:2*kmax/(ml-1):kmax);

% object image field in frequency domain
objectFT = fftshift(fft2(object)); % FT over the object 
figure(201); imagesc(log(abs(objectFT)));axis image;
ax=gca; ax.FontSize = 10;
title(['obj. FT. abs (log) full']); axis on;
saveas(figure(201), './output/objectFT_abs.jpg');

figure(202); imshow(log(angle(objectFT)));
axis image; 
ax=gca; ax.FontSize = 10;
title(['obj. FT. phase (log) full']); axis on;
saveas(figure(202), './output/objectFT_angle.jpg');

% (circular aperture in frequency domain)
CTF = ((kxm.^2+kym.^2) < cutoffFrequency^2); % coherent transfer function 
f203 = figure(203); imshow(CTF);
set(f203, 'PaperSize', [10 10]);
set(f203,'Position',[100 100 300 300])
axis on; axis tight;
ax=gca;
ax.FontSize = 20;
saveas(figure(203), './output/CTF.jpg');

%%
kxcr = zeros(num_LEDs);
kycr = zeros(num_LEDs);

for nr = 1:num_LEDs % number of LEDs 

    fprintf('%d ',nr); 

    kxcr(nr) = round((n+1)/2 + kx(1,nr)/dkx); % center of kx 
    kycr(nr) = round((m+1)/2 + ky(1,nr)/dky); % center of ky 
end

%%
for nr = 1:num_LEDs % number of LEDs 

    fprintf('%d ',nr); 

    kxc = round((n+1)/2 + kx(1,nr)/dkx); % center of kx 
    kyc = round((m+1)/2 + ky(1,nr)/dky); % center of ky 

    kxl = round(kxc-(nl-1)/2); kxh=round(kxc+(nl-1)/2); % kx low and high 
    kyl = round(kyc-(ml-1)/2); kyh=round(kyc+(ml-1)/2); % ky low and high 

    imSeqLowFT = (ml/m)^2 * objectFT(kyl:kyh, kxl:kxh).*CTF; % Freq domain 

    imSeqLowRes_abs(:,:,nr) = abs(ifft2(ifftshift(imSeqLowFT))); % Spatial domain 

end

fprintf('\n');
%%
%figure(3);imshow(imSeqLowRes(:,:,round(num_LEDs/2)),[]);

%% Low Res imgs abs 
imgArray = 1;

if imgArray == 1

    rows = arraysize;
    cols = arraysize;
    figure(4);
    
    for iRow = 1:rows
        for iCol = 1:cols
            subplot(rows,cols,prc(cols,[iRow iCol]));
            title(['Subplot ',num2str(prc(cols,[iRow iCol]))],'fontSize',14);
            text(0.5,0.5,[num2str(iRow),', ',num2str(iCol)],...
                'HorizontalAlignment','center','fontsize',14);

            nr_imgArray = iRow*iCol;

            imagesc(imSeqLowRes_abs(:,:,nr_imgArray));
            axis image; axis tight;

        end
    end
end

saveas(figure(4), './output/wide_field_low_res_imgs_abs.jpg')

%% reconstruct a high resolution image
seq = gseq(arraysize); % 
objectRecover = ones(m,n); % object initial guess
objectRecoverFT = fftshift(fft2(objectRecover)); % complex number 
iter = 2;
for it=1:iter
    for i=1:num_LEDs % LEDs nr 
        j=seq(i);
        fprintf('seq nr: %d/%d, ', j, arraysize^2)
        kxc = round((n+1)/2+kx(1,j)/dkx); % pos center x
        kyc = round((m+1)/2+ky(1,j)/dky); % pos center y 
        kyl = round(kyc-(ml-1)/2); kyh = round(kyc+(ml-1)/2); % sub area x 
        kxl = round(kxc-(nl-1)/2); kxh = round(kxc+(nl-1)/2); % sub area y
        lowResFT = (ml/m)^2 * objectRecoverFT(kyl:kyh, kxl:kxh).*CTF; % sub imgs 
        im_lowRes = ifft2(ifftshift(lowResFT)); % Frequency of sub imgs 
        im_lowRes = (m/ml)^2*imSeqLowRes_abs(:,:,j).*exp(1i.*angle(im_lowRes)); % replace of the Im  
        lowResFT = fftshift(fft2(im_lowRes)).*CTF; % Frequency of the sub region 
        %objectRecoverFT(kyl:kyh,kxl:kxh)=(1-CTF).*objectRecoverFT(kyl:kyh,kxl:kxh)+lowResFT; % update (add) the sub region frequency 
        objectRecoverFT(kyl:kyh,kxl:kxh)=objectRecoverFT(kyl:kyh,kxl:kxh)+lowResFT; % update (add) the sub region frequency 
    end
end
objectRecon=ifft2(ifftshift(objectRecoverFT)); % full recover image 

fprintf('low res FT: (%d, %d) \n', size(lowResFT));
fprintf('im lowRes: (%d, %d) \n', size(im_lowRes));

fprintf('object Recover FT: (%d, %d) \n', size(objectRecoverFT,1), size(objectRecoverFT,2));
fprintf('object recon: (%d, %d) \n', size(objectRecon,1), size(objectRecon,2));


%% visual test 

% test ctf in the lowResFT



% test ctf in the objectRecoverFT 



%%
figure(61);imshow(log(abs(objectRecoverFT)),[]);
title(['amp. obj. FT. (log), nr=', num2str(j)]);axis on;

figure(62);imshow(log(angle(objectRecoverFT)),[]);
title(['phase obj. FT. (log), nr=', num2str(j)]);axis on;

saveas(figure(61), './output/obj_FT_amp.jpg')
saveas(figure(62), './output/obj_FT_phase.jpg')


figure(8);imshow(abs(objectRecon),[]);
title('obj. amp. recon.');axis on;
saveas(figure(8), './output/ObjRecon_amp.jpg')

figure(9);imshow(angle(objectRecon),[]);
title('obj. phase recon.');axis on;
saveas(figure(9), './output/ObjRecon_phase.jpg')




