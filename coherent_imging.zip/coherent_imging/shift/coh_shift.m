% coherent imaging process simulation
clc; clear;

%% Test image of a high-resolution object
objectIntensity = double(imread('../../Test_imgs/GXLK8161.tif'));
fprintf('object shape: %d %d\n', size(objectIntensity));
objectAmplitude = sqrt(objectIntensity);

%% setup parameters for the coherent imaging system
waveLength = 0.6238e-6; % Red HeNe 
k0=2*pi/waveLength; % wavenumber
pixelSize = 3.45e-6; % Thorlab Kialux CS505CU1 px=3.45e-6
NA = 0.01; 
cutoffFrequence = NA*k0;

%% set up the low-pass filter in Fourier domain 
objectAmplitudeFT=fftshift(fft2(objectAmplitude));
[m, n] = size(objectAmplitude);
% min, step, max wavevector in the detector
kx=-pi/pixelSize:2*pi/(pixelSize*(n-1)):pi/pixelSize; 
ky=-pi/pixelSize:2*pi/(pixelSize*(n-1)):pi/pixelSize;
[kxm, kym]=meshgrid(kx,ky); % meshgrid for all wavevectors in x/y axis in FD
% coherent pupil function 
CTF=((kxm.^2+kym.^2)<cutoffFrequence^2); % coherent transfer function 

% incident angle x/y
theta_x = 0;
theta_y = 0;

% x/y shift in k-domain
kx_s = k0*theta_x; ky_s = k0*theta_y;
CTF_s=(((kxm-kx_s).^2+(kym-ky_s).^2)<cutoffFrequence^2); % coherent transfer function 

%% filtering process
outputFT=CTF_s.*objectAmplitudeFT;

%% output amplitude and intensity
outputAmplitude = ifft2(ifftshift(outputFT));
outputIntensity = abs(outputAmplitude).^2;
port_w = 200; port_r = 380; port_c = 580; 
outputIntensity_port = outputIntensity(port_r:port_r+port_w, port_c:port_c+port_w);

%% figure
figure(10);
imshow(objectAmplitude, []); title('Input object (amplitude)');

f100 = figure(100);
x0 = 300; y0 = 300; width = 1000; height = 600;
set(f100, 'Position', [x0, y0, width, height]);

subplot(3,5,1);
imshow(CTF, []);title(sprintf('NA %.3f', NA));

subplot(3,5,2);
imshow(log(abs(outputFT)),[]); title(sprintf('x-off:%.3f', theta_x)); 

subplot(3,5,[3,4,5,8:9,13:15]); 
imshow(outputIntensity, []); title('Output (I)'); 

subplot(3,5,[6,7,11,12]); 
imshow(outputIntensity_port, []); title('Output (I)'); axis tight;
