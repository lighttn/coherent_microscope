% coherent imaging process simulation
clc; clear;

%% Test image of a high-resolution object
objectIntensity = double(imread('../Test_imgs/GXLK8161.tif'));
fprintf('object shape: %d %d\n', size(objectIntensity));
objectAmplitude = sqrt(objectIntensity);

%% setup parameters for the coherent imaging system
waveLength = 0.6238e-6; % Red HeNe 
k0=2*pi/waveLength; % wavenumber
pixelSize = 3.45e-6; % Thorlab Kialux CS505CU1 px=3.45e-6
NA = 0.1; 
cutoffFrequence = NA*k0;

%% set up the low-pass filter in Fourier domain 
objectAmplitudeFT=fftshift(fft2(objectAmplitude));
[m, n] = size(objectAmplitude);
% min, step, max wavevector in the detector
kx=-pi/pixelSize:2*pi/(pixelSize*(n-1)):pi/pixelSize; 
ky=-pi/pixelSize:2*pi/(pixelSize*(n-1)):pi/pixelSize;
[kxm, kym]=meshgrid(kx,ky); % meshgrid for all wavevectors in x/y axis in FD
% coherent pupil function 
CTF=((kxm.^2+kym.^2)<cutoffFrequence^2); % coherent transfer function 

%% filtering process
outputFT=CTF.*objectAmplitudeFT;

%% output amplitude and intensity
outputAmplitude = ifft2(ifftshift(outputFT));
outputIntensity = abs(outputAmplitude).^2;

%% figure
figure(10);
imshow(objectAmplitude, []); title('Input object (amplitude)');

f100 = figure(100);
x0 = 300; y0 = 300; width = 300; height = 450;
set(f100, 'Position', [x0, y0, width, height]);

subplot(3,2,1);
imshow(CTF, []);title(sprintf('pupil NA %.3f', NA));

subplot(3,2,2);
imshow(log(abs(outputFT)),[]);
title('Filtered spectrum');

subplot(3,2,[3,4,5,6]); 
imshow(outputIntensity, []); title('Output (I)'); axis tight;

